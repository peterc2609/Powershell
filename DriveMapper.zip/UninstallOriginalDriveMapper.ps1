[CmdletBinding()]
Param(
    [string]$TaskName = "IntuneDriveMapping",
    [string]$ScriptFolder = "C:\ProgramData\Microsoft\IntuneApps\DriveMapping",
    [string]$TempXmlFile = "$env:TEMP\DriveMappingTask.xml"
)

# Stop the task if it's running
if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    try {
        Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction Stop
        Write-Output "Scheduled task '$TaskName' removed successfully."
    } catch {
        Write-Warning "Failed to remove task '$TaskName': $_"
    }
} else {
    Write-Output "Scheduled task '$TaskName' not found."
}

# Remove the script folder and files
if (Test-Path $ScriptFolder) {
    try {
        Remove-Item -Path $ScriptFolder -Recurse -Force
        Write-Output "Removed folder: $ScriptFolder"
    } catch {
        Write-Warning "Failed to delete $ScriptFolder: $_"
    }
} else {
    Write-Output "Script folder not found: $ScriptFolder"
}

# Remove temp XML if it exists
if (Test-Path $TempXmlFile) {
    try {
        Remove-Item $TempXmlFile -Force
        Write-Output "Removed temp XML file: $TempXmlFile"
    } catch {
        Write-Warning "Failed to delete $TempXmlFile: $_"
    }
}

Write-Output "Uninstall completed."