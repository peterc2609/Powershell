[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$TaskName
)

Write-Output "Attempting to uninstall scheduled task: $TaskName"

# Unregister the scheduled task
if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    try {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
        Write-Output "Task '$TaskName' successfully removed."
    } catch {
        Write-Output "Failed to remove task '$TaskName': $_"
    }
} else {
    Write-Output "⚠ Task '$TaskName' not found."
}